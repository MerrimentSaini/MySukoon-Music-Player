import React, { createContext, useContext, useState, useEffect } from 'react';

const StorageContext = createContext(null);

export const useStorage = () => {
  const context = useContext(StorageContext);
  if (!context) {
    throw new Error('useStorage must be used within a StorageProvider');
  }
  return context;
};

const RANDOM_GRADIENTS = [
  'from-pink-500 to-rose-500',
  'from-purple-600 to-indigo-600',
  'from-emerald-500 to-teal-500',
  'from-cyan-500 to-blue-500',
  'from-amber-500 to-orange-500',
  'from-violet-600 to-purple-600',
  'from-red-500 to-pink-500',
  'from-blue-600 to-indigo-700'
];

export const StorageProvider = ({ children }) => {
  const [favorites, setFavorites] = useState([]);
  const [playlists, setPlaylists] = useState([]);
  const [recentlyPlayed, setRecentlyPlayed] = useState([]);
  const [user, setUser] = useState({ isLoggedIn: false, name: '', avatar: '' });
  const [amoledMode, setAmoledMode] = useState(false);
  const [theme, setTheme] = useState('dark');

  // Load initial data
  useEffect(() => {
    try {
      const storedFavorites = JSON.parse(localStorage.getItem('mysukoon_favorites') || localStorage.getItem('mysukoon_liked') || '[]');
      const storedPlaylists = JSON.parse(localStorage.getItem('mysukoon_playlists') || '[]');
      const storedRecent = JSON.parse(localStorage.getItem('mysukoon_recently_played') || localStorage.getItem('mysukoon_history') || '[]');
      const storedUser = JSON.parse(localStorage.getItem('mysukoon_user') || localStorage.getItem('mysukoon_profile') || '{"isLoggedIn":false,"name":"","avatar":""}');
      const isAmoled = localStorage.getItem('mysukoon_amoled') === 'true';
      const storedTheme = localStorage.getItem('mysukoon_theme') || 'dark';

      setFavorites(storedFavorites);
      setPlaylists(storedPlaylists);
      setRecentlyPlayed(storedRecent);
      setUser(storedUser);
      setAmoledMode(isAmoled);
      setTheme(storedTheme);

      if (isAmoled) {
        document.body.classList.add('amoled-theme');
      }

      if (storedTheme === 'light') {
        document.documentElement.classList.add('light-theme');
        document.documentElement.classList.remove('dark-theme');
      } else {
        document.documentElement.classList.add('dark-theme');
        document.documentElement.classList.remove('light-theme');
      }
    } catch (e) {
      console.error('Failed to load local storage data', e);
    }
  }, []);

  // Sync recently played on custom event from AudioContext
  useEffect(() => {
    const syncRecentlyPlayed = () => {
      try {
        const storedRecent = JSON.parse(localStorage.getItem('mysukoon_recently_played') || localStorage.getItem('mysukoon_history') || '[]');
        setRecentlyPlayed(storedRecent);
      } catch (e) {
        console.error('Error syncing recently played', e);
      }
    };

    window.addEventListener('storage_update', syncRecentlyPlayed);
    window.addEventListener('storage', syncRecentlyPlayed); // standard storage sync
    
    return () => {
      window.removeEventListener('storage_update', syncRecentlyPlayed);
      window.removeEventListener('storage', syncRecentlyPlayed);
    };
  }, []);

  // --- Favorites Manager ---
  const addFavorite = (track) => {
    if (favorites.some(t => t.id === track.id)) return;
    const updated = [track, ...favorites];
    setFavorites(updated);
    localStorage.setItem('mysukoon_favorites', JSON.stringify(updated));
    localStorage.setItem('mysukoon_liked', JSON.stringify(updated));
  };

  const removeFavorite = (trackId) => {
    const updated = favorites.filter(t => t.id !== trackId);
    setFavorites(updated);
    localStorage.setItem('mysukoon_favorites', JSON.stringify(updated));
    localStorage.setItem('mysukoon_liked', JSON.stringify(updated));
  };

  const isFavorite = (trackId) => {
    return favorites.some(t => t.id === trackId);
  };

  const toggleFavorite = (track) => {
    if (isFavorite(track.id)) {
      removeFavorite(track.id);
    } else {
      addFavorite(track);
    }
  };

  // --- Playlists Manager ---
  const createPlaylist = (name, description = '') => {
    const randomGradient = RANDOM_GRADIENTS[Math.floor(Math.random() * RANDOM_GRADIENTS.length)];
    const newPlaylist = {
      id: `playlist_${Date.now()}`,
      name,
      description,
      gradient: randomGradient,
      tracks: [],
      createdAt: new Date().toISOString()
    };
    const updated = [...playlists, newPlaylist];
    setPlaylists(updated);
    localStorage.setItem('mysukoon_playlists', JSON.stringify(updated));
    return newPlaylist;
  };

  const deletePlaylist = (playlistId) => {
    const updated = playlists.filter(p => p.id !== playlistId);
    setPlaylists(updated);
    localStorage.setItem('mysukoon_playlists', JSON.stringify(updated));
  };

  const addTrackToPlaylist = (playlistId, track) => {
    const updated = playlists.map(p => {
      if (p.id === playlistId) {
        // Prevent duplicate songs in playlist
        if (p.tracks.some(t => t.id === track.id)) return p;
        return {
          ...p,
          tracks: [...p.tracks, track]
        };
      }
      return p;
    });
    setPlaylists(updated);
    localStorage.setItem('mysukoon_playlists', JSON.stringify(updated));
  };

  const removeTrackFromPlaylist = (playlistId, trackId) => {
    const updated = playlists.map(p => {
      if (p.id === playlistId) {
        return {
          ...p,
          tracks: p.tracks.filter(t => t.id !== trackId)
        };
      }
      return p;
    });
    setPlaylists(updated);
    localStorage.setItem('mysukoon_playlists', JSON.stringify(updated));
  };

  // --- User Profile Session ---
  const loginUser = (name, avatar) => {
    const session = { isLoggedIn: true, name, avatar };
    setUser(session);
    localStorage.setItem('mysukoon_user', JSON.stringify(session));
    localStorage.setItem('mysukoon_profile', JSON.stringify(session));
  };

  const logoutUser = () => {
    const session = { isLoggedIn: false, name: '', avatar: '' };
    setUser(session);
    localStorage.removeItem('mysukoon_user');
    localStorage.removeItem('mysukoon_profile');
  };

  const updateUserProfile = (name, avatarBase64) => {
    const updated = { isLoggedIn: true, name, avatar: avatarBase64 };
    setUser(updated);
    localStorage.setItem('mysukoon_user', JSON.stringify(updated));
    localStorage.setItem('mysukoon_profile', JSON.stringify(updated));
  };

  const toggleAmoledMode = () => {
    const nextVal = !amoledMode;
    setAmoledMode(nextVal);
    localStorage.setItem('mysukoon_amoled', nextVal ? 'true' : 'false');
    if (nextVal) {
      document.body.classList.add('amoled-theme');
    } else {
      document.body.classList.remove('amoled-theme');
    }
  };

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    localStorage.setItem('mysukoon_theme', nextTheme);
    if (nextTheme === 'light') {
      document.documentElement.classList.add('light-theme');
      document.documentElement.classList.remove('dark-theme');
    } else {
      document.documentElement.classList.add('dark-theme');
      document.documentElement.classList.remove('light-theme');
    }
  };

  const clearListeningHistory = () => {
    localStorage.removeItem('mysukoon_history_plays');
    localStorage.removeItem('mysukoon_history_skips');
    localStorage.removeItem('mysukoon_history_artists');
    localStorage.removeItem('mysukoon_history_genres');
    localStorage.removeItem('mysukoon_history_moods');
    localStorage.removeItem('mysukoon_history_recent');
    localStorage.removeItem('mysukoon_recently_played');
    localStorage.removeItem('mysukoon_history');
    localStorage.removeItem('mysukoon_history_search');
    localStorage.removeItem('mysukoon_stats_time');
    
    setRecentlyPlayed([]);
    window.dispatchEvent(new Event('storage_update'));
  };

  return (
    <StorageContext.Provider value={{
      favorites,
      playlists,
      recentlyPlayed,
      user,
      amoledMode,
      theme,
      addFavorite,
      removeFavorite,
      isFavorite,
      toggleFavorite,
      createPlaylist,
      deletePlaylist,
      addTrackToPlaylist,
      removeTrackFromPlaylist,
      loginUser,
      logoutUser,
      updateUserProfile,
      toggleAmoledMode,
      toggleTheme,
      clearListeningHistory
    }}>
      {children}
    </StorageContext.Provider>
  );
};
