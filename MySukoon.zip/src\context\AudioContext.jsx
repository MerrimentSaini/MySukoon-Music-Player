import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { getStreamUrl } from '../services/jamendoApi';
import { trackPlay, trackSkip, solveNextAutoplay } from '../services/recommendationEngine';

const AudioContext = createContext(null);

export const useAudio = () => {
  const context = useContext(AudioContext);
  if (!context) {
    throw new Error('useAudio must be used within an AudioProvider');
  }
  return context;
};

export const AudioProvider = ({ children }) => {
  // Global native audio element reference
  const audioRef = useRef(new Audio());
  
  // Track retries dynamically to prevent infinite loops
  const retryCountRef = useRef(0);

  // YouTube player references
  const ytPlayerRef = useRef(null);
  const [isYtReady, setIsYtReady] = useState(false);
  const pendingVideoIdRef = useRef(null);
  
  // States
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [isShuffle, setIsShuffle] = useState(false);
  const [isRepeat, setIsRepeat] = useState('none'); // 'none' | 'one' | 'all'
  const [queue, setQueue] = useState([]);
  const [queueIndex, setQueueIndex] = useState(-1);
  const [isMuted, setIsMuted] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);

  // Keep track of the original shuffle order if we want, or just randomize indices
  const originalQueueRef = useRef([]);

  // Initialize cross-origin permissions
  useEffect(() => {
    audioRef.current.crossOrigin = "anonymous";
  }, []);

  // --- YouTube Player Lifecycle Setup ---
  const initYoutubePlayer = () => {
    if (ytPlayerRef.current) return;
    const container = document.getElementById('youtube-player');
    if (!container) return;

    try {
      console.log('[Audio Engine] Initializing YouTube IFrame Player...');
      ytPlayerRef.current = new window.YT.Player('youtube-player', {
        height: '100%',
        width: '100%',
        videoId: '',
        playerVars: {
          autoplay: 1,
          controls: 0, // hide native controls for audio-focused experience
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          rel: 0,
          showinfo: 0,
          iv_load_policy: 3,
          origin: window.location.origin
        },
        events: {
          onReady: (event) => {
            console.log('[Audio Engine] YouTube Player instance ready');
            setIsYtReady(true);
            event.target.setVolume(volume * 100);
            if (isMuted) event.target.mute();
            
            // If we have a pending video, load it now!
            if (pendingVideoIdRef.current) {
              console.log('[Audio Engine] Playing pending YouTube video:', pendingVideoIdRef.current);
              event.target.loadVideoById(pendingVideoIdRef.current);
              pendingVideoIdRef.current = null;
              setIsPlaying(true);
            } else if (currentTrack?.isYouTube) {
              event.target.loadVideoById(currentTrack.videoId);
              setIsPlaying(true);
            }
          },
          onStateChange: (event) => {
            const state = event.data;
            if (state === window.YT.PlayerState.PLAYING) {
              setIsPlaying(true);
              setIsBuffering(false);
              // Synced speed booster
              if (ytPlayerRef.current && typeof ytPlayerRef.current.setPlaybackRate === 'function') {
                try {
                  ytPlayerRef.current.setPlaybackRate(playbackSpeed);
                } catch (e) {}
              }
            } else if (state === window.YT.PlayerState.PAUSED) {
              setIsPlaying(false);
              setIsBuffering(false);
            } else if (state === window.YT.PlayerState.BUFFERING) {
              setIsBuffering(true);
            } else if (state === window.YT.PlayerState.ENDED) {
              setIsBuffering(false);
              setIsPlaying(false);
              playNext(true); // Auto-advance queue
            }
          },
          onError: (event) => {
            console.error('[Audio Engine] YouTube Player error event:', event.data);
            setIsBuffering(false);
            setIsPlaying(false);
          }
        }
      });
    } catch (e) {
      console.error('[Audio Engine] Failed to initialize YouTube player:', e);
    }
  };

  const ensureYoutubePlayerInitialized = () => {
    if (ytPlayerRef.current && typeof ytPlayerRef.current.loadVideoById === 'function') {
      return true;
    }
    if (!window.YT || !window.YT.Player) return false;
    initYoutubePlayer();
    return true;
  };

  // Dynamically load YouTube Player API
  useEffect(() => {
    if (!window.YT) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      const firstScriptTag = document.getElementsByTagName('script')[0];
      firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
    }

    const prevCallback = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      if (prevCallback) prevCallback();
      setTimeout(() => {
        initYoutubePlayer();
      }, 500);
    };

    if (window.YT && window.YT.Player) {
      setTimeout(() => {
        initYoutubePlayer();
      }, 500);
    }
  }, []);

  // Polling interval to keep YouTube playback times updated
  useEffect(() => {
    let timer;
    if (isPlaying && currentTrack?.isYouTube) {
      timer = setInterval(() => {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.getCurrentTime === 'function') {
          try {
            const time = ytPlayerRef.current.getCurrentTime();
            const dur = ytPlayerRef.current.getDuration();
            setCurrentTime(time || 0);
            if (dur && dur > 0) {
              setDuration(dur);
            }
          } catch (e) {}
        }
      }, 250);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [isPlaying, currentTrack]);

  // Initialize and attach native audio event listeners
  useEffect(() => {
    const audio = audioRef.current;
    audio.volume = volume;

    const handlePlay = () => {
      setIsPlaying(true);
      setIsBuffering(false);
    };
    const handlePause = () => setIsPlaying(false);
    const handleDurationChange = () => {
      if (!currentTrack?.isYouTube) {
        setDuration(audio.duration || 0);
      }
    };
    const handleTimeUpdate = () => {
      if (!currentTrack?.isYouTube) {
        setCurrentTime(audio.currentTime || 0);
      }
    };
    
    // Buffering and loading event handlers
    const handleWaiting = () => setIsBuffering(true);
    const handlePlaying = () => {
      setIsPlaying(true);
      setIsBuffering(false);
    };
    const handleCanPlay = () => setIsBuffering(false);
    const handleSeeking = () => setIsBuffering(true);
    const handleSeeked = () => setIsBuffering(false);
    const handleLoadStart = () => setIsBuffering(true);
    const handleLoadedData = () => setIsBuffering(false);

    // Automatic Recovery Retry logic on errors
    const handleAudioError = () => {
      console.warn(`[Audio Engine] Playback error encountered:`, audio.error);
      setIsBuffering(false);
      
      if (retryCountRef.current < 3 && currentTrack?.audio) {
        retryCountRef.current += 1;
        const savedTime = audio.currentTime;
        console.log(`[Audio Engine] Attempting automatic playback recovery (Retry ${retryCountRef.current}/3) at position ${savedTime}s...`);
        
        setTimeout(() => {
          const proxyStreamUrl = getStreamUrl(currentTrack.audio);
          audio.src = proxyStreamUrl;
          audio.load();
          audio.currentTime = savedTime;
          audio.play()
            .then(() => {
              console.log('[Audio Engine] Playback recovery succeeded!');
              retryCountRef.current = 0; // reset
            })
            .catch(err => {
              console.error('[Audio Engine] Playback recovery retry failed:', err);
            });
        }, 1500);
      } else {
        console.error('[Audio Engine] Maximum auto-retries reached. Playback failed permanently.');
        setIsPlaying(false);
      }
    };

    const handleEnded = () => {
      if (isRepeat === 'one') {
        audio.currentTime = 0;
        audio.play().catch(err => console.error('Audio auto replay failed:', err));
      } else {
        playNext(true); // Automatically advance
      }
    };

    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleAudioError);
    
    // Add new buffering listeners
    audio.addEventListener('waiting', handleWaiting);
    audio.addEventListener('playing', handlePlaying);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('seeking', handleSeeking);
    audio.addEventListener('seeked', handleSeeked);
    audio.addEventListener('loadstart', handleLoadStart);
    audio.addEventListener('loadeddata', handleLoadedData);

    return () => {
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleAudioError);
      
      // Clean up buffering listeners
      audio.removeEventListener('waiting', handleWaiting);
      audio.removeEventListener('playing', handlePlaying);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('seeking', handleSeeking);
      audio.removeEventListener('seeked', handleSeeked);
      audio.removeEventListener('loadstart', handleLoadStart);
      audio.removeEventListener('loadeddata', handleLoadedData);
    };
  }, [isRepeat, queue, queueIndex, isShuffle, currentTrack]);

  // Handle source changes
  useEffect(() => {
    const audio = audioRef.current;
    if (!currentTrack) return;

    // Track play history in AI recommendation database
    trackPlay(currentTrack);

    if (currentTrack.isYouTube) {
      // Pause and clear native player
      audio.pause();
      audio.src = '';
      
      setIsBuffering(true);
      setCurrentTime(0);
      setDuration(currentTrack.duration || 240);
      
      const inited = ensureYoutubePlayerInitialized();
      if (inited && ytPlayerRef.current && typeof ytPlayerRef.current.loadVideoById === 'function') {
        try {
          ytPlayerRef.current.loadVideoById({
            videoId: currentTrack.videoId,
            startSeconds: 0
          });
          ytPlayerRef.current.setVolume(volume * 100);
          if (isMuted) {
            ytPlayerRef.current.mute();
          } else {
            ytPlayerRef.current.unMute();
          }
          setIsPlaying(true);
        } catch (err) {
          console.error('[Audio Engine] Failed loading YouTube video:', err);
        }
      } else {
        // Player is not ready yet! Queue it as a pending load!
        console.log('[Audio Engine] YouTube player not ready yet. Queuing video ID:', currentTrack.videoId);
        pendingVideoIdRef.current = currentTrack.videoId;
      }
      
      saveToRecentlyPlayed(currentTrack);
      updateMediaSessionMetadata(currentTrack);
    } else if (currentTrack.audio) {
      // Pause YouTube player if active
      if (ytPlayerRef.current && typeof ytPlayerRef.current.pauseVideo === 'function') {
        try {
          ytPlayerRef.current.pauseVideo();
        } catch (e) {}
      }

      // Reset error retries for a new track
      retryCountRef.current = 0;
      
      // Load proxied backend stream url to eliminate CORS errors and blocks
      const proxyStreamUrl = getStreamUrl(currentTrack.audio);
      audio.src = proxyStreamUrl;
      audio.load();
      audio.playbackRate = playbackSpeed;
      
      // Auto play when currentTrack changes (standard Spotify behavior)
      audio.play()
        .then(() => setIsPlaying(true))
        .catch(err => {
          console.error('Audio play failed:', err);
          setIsPlaying(false);
        });

      // Track history in recently played
      saveToRecentlyPlayed(currentTrack);
      
      // Set Media Session API metadata
      updateMediaSessionMetadata(currentTrack);
    }
  }, [currentTrack]);

  // Sync playback speed across both HTML5 Audio and YouTube players
  useEffect(() => {
    const audio = audioRef.current;
    audio.playbackRate = playbackSpeed;
    
    if (ytPlayerRef.current && typeof ytPlayerRef.current.setPlaybackRate === 'function') {
      try {
        ytPlayerRef.current.setPlaybackRate(playbackSpeed);
      } catch (e) {}
    }
  }, [playbackSpeed, currentTrack, isPlaying]);

  // Sync volume & mute
  useEffect(() => {
    audioRef.current.volume = isMuted ? 0 : volume;
    if (ytPlayerRef.current && typeof ytPlayerRef.current.setVolume === 'function') {
      try {
        if (isMuted) {
          ytPlayerRef.current.mute();
        } else {
          ytPlayerRef.current.unMute();
          ytPlayerRef.current.setVolume(volume * 100);
        }
      } catch (e) {}
    }
  }, [volume, isMuted]);

  // Sync Media Session Playback State
  useEffect(() => {
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
    }
  }, [isPlaying]);

  // Setup Media Session Action Handlers
  useEffect(() => {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.setActionHandler('play', () => {
          togglePlay();
        });
        navigator.mediaSession.setActionHandler('pause', () => {
          togglePlay();
        });
        navigator.mediaSession.setActionHandler('previoustrack', () => {
          playPrevious();
        });
        navigator.mediaSession.setActionHandler('nexttrack', () => {
          playNext();
        });
        navigator.mediaSession.setActionHandler('seekto', (details) => {
          if (details.seekTime !== undefined) {
            seek(details.seekTime);
          }
        });
      } catch (error) {
        console.warn('Media Session Action Handlers registration failed:', error);
      }
    }
  }, [queue, queueIndex, isPlaying]);

  // --- Recently Played Helper ---
  const saveToRecentlyPlayed = (track) => {
    if (!track) return;
    try {
      const recent = JSON.parse(localStorage.getItem('mysukoon_recently_played') || '[]');
      // Filter out existing instances of the same track
      const filtered = recent.filter(t => t.id !== track.id);
      // Put new track at the beginning
      const updated = [track, ...filtered].slice(0, 20); // Cap at 20
      localStorage.setItem('mysukoon_recently_played', JSON.stringify(updated));
      // Dispatch a storage event so StorageContext knows to update
      window.dispatchEvent(new Event('storage_update'));
    } catch (e) {
      console.error('Failed to update recently played in localStorage', e);
    }
  };

  // --- Media Session Metadata helper ---
  const updateMediaSessionMetadata = (track) => {
    if ('mediaSession' in navigator && track) {
      const artUrl = track.shareimage || track.image || 'https://placehold.co/400x400/181818/ffffff?text=MySukoon';
      navigator.mediaSession.metadata = new MediaMetadata({
        title: track.name,
        artist: track.artist_name,
        album: track.album_name || 'MySukoon Single',
        artwork: [
          { src: artUrl, sizes: '96x96', type: 'image/jpeg' },
          { src: artUrl, sizes: '128x128', type: 'image/jpeg' },
          { src: artUrl, sizes: '192x192', type: 'image/jpeg' },
          { src: artUrl, sizes: '256x256', type: 'image/jpeg' },
          { src: artUrl, sizes: '384x384', type: 'image/jpeg' },
          { src: artUrl, sizes: '512x512', type: 'image/jpeg' },
        ]
      });
    }
  };

  // --- Controls Functions ---
  const togglePlay = () => {
    if (!currentTrack) return;
    
    if (currentTrack.isYouTube) {
      ensureYoutubePlayerInitialized();
      if (ytPlayerRef.current && typeof ytPlayerRef.current.getPlayerState === 'function') {
        try {
          const state = ytPlayerRef.current.getPlayerState();
          if (state === window.YT.PlayerState.PLAYING) {
            ytPlayerRef.current.pauseVideo();
            setIsPlaying(false);
          } else {
            ytPlayerRef.current.playVideo();
            setIsPlaying(true);
          }
        } catch (e) {
          console.error('[Audio Engine] YouTube play toggle failed:', e);
        }
      } else {
        // If the player is loading but not fully ready, and we toggle play
        if (isPlaying) {
          setIsPlaying(false);
          pendingVideoIdRef.current = null; // Cancel pending load
        } else {
          setIsPlaying(true);
          pendingVideoIdRef.current = currentTrack.videoId; // Set pending load
        }
      }
    } else {
      const audio = audioRef.current;
      if (isPlaying) {
        audio.pause();
        setIsPlaying(false);
      } else {
        audio.play()
          .then(() => setIsPlaying(true))
          .catch(err => console.error('Play failed:', err));
      }
    }
  };

  const seek = (time) => {
    if (currentTrack?.isYouTube) {
      ensureYoutubePlayerInitialized();
      if (ytPlayerRef.current && typeof ytPlayerRef.current.seekTo === 'function') {
        try {
          ytPlayerRef.current.seekTo(time, true);
          setCurrentTime(time);
        } catch (e) {
          console.error('[Audio Engine] YouTube seek failed:', e);
        }
      }
    } else {
      const audio = audioRef.current;
      audio.currentTime = time;
      setCurrentTime(time);
    }
  };

  const changeVolume = (val) => {
    const v = parseFloat(val);
    setVolume(v);
    if (v > 0) setIsMuted(false);
    
    if (ytPlayerRef.current && typeof ytPlayerRef.current.setVolume === 'function') {
      try {
        ytPlayerRef.current.setVolume(v * 100);
      } catch (e) {}
    }
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    
    if (ytPlayerRef.current && typeof ytPlayerRef.current.mute === 'function') {
      try {
        if (nextMuted) {
          ytPlayerRef.current.mute();
        } else {
          ytPlayerRef.current.unMute();
          ytPlayerRef.current.setVolume(volume * 100);
        }
      } catch (e) {}
    }
  };

  const changeSpeed = (speed) => {
    setPlaybackSpeed(parseFloat(speed));
  };

  const selectTrack = (track, trackList = []) => {
    if (!track) return;
    
    // Update queue context if a new list is provided
    if (trackList.length > 0) {
      setQueue(trackList);
      const index = trackList.findIndex(t => t.id === track.id);
      setQueueIndex(index !== -1 ? index : 0);
    } else {
      // Just playing single track: Add to queue if not present, and play
      const idx = queue.findIndex(t => t.id === track.id);
      if (idx !== -1) {
        setQueueIndex(idx);
      } else {
        const newQueue = [...queue, track];
        setQueue(newQueue);
        setQueueIndex(newQueue.length - 1);
      }
    }
    
    setCurrentTrack(track);
  };

  const playNext = (auto = false) => {
    if (queue.length === 0) return;

    if (auto && isRepeat === 'one' && currentTrack) {
      if (currentTrack.isYouTube) {
        if (ytPlayerRef.current && typeof ytPlayerRef.current.seekTo === 'function') {
          try {
            ytPlayerRef.current.seekTo(0, true);
            ytPlayerRef.current.playVideo();
            setIsPlaying(true);
            return;
          } catch (e) {}
        }
      } else {
        audioRef.current.currentTime = 0;
        audioRef.current.play().catch(err => console.error('Audio auto replay failed:', err));
        return;
      }
    }

    // Skip logging on manual next click
    if (!auto && currentTrack && currentTime > 2 && currentTime < 25) {
      console.log('[AI Engine] User skipped track quickly:', currentTrack.name);
      trackSkip(currentTrack);
    }

    if (isShuffle) {
      // Smart Shuffle AI: Choose the highest scoring track in context
      const nextAiTrack = solveNextAutoplay(currentTrack, queue);
      if (nextAiTrack) {
        selectTrack(nextAiTrack);
        return;
      }
      const randomIndex = Math.floor(Math.random() * queue.length);
      setQueueIndex(randomIndex);
      setCurrentTrack(queue[randomIndex]);
      return;
    }

    let nextIndex = queueIndex + 1;

    if (nextIndex >= queue.length) {
      if (isRepeat === 'all') {
        nextIndex = 0; // Wrap around
      } else if (auto) {
        // AI Autoplay activation when song reaches the end!
        console.log('[AI Engine] Autoplay solved next track...');
        const nextAiTrack = solveNextAutoplay(currentTrack, queue);
        if (nextAiTrack) {
          selectTrack(nextAiTrack);
          return;
        }
        setIsPlaying(false);
        audioRef.current.pause();
        if (ytPlayerRef.current && typeof ytPlayerRef.current.stopVideo === 'function') {
          try {
            ytPlayerRef.current.stopVideo();
          } catch (e) {}
        }
      } else {
        return;
      }
    } else {
      setQueueIndex(nextIndex);
      setCurrentTrack(queue[nextIndex]);
    }
  };

  const playPrevious = () => {
    if (queue.length === 0) return;

    // Skip logging on manual back click
    if (currentTrack && currentTime > 2 && currentTime < 25) {
      console.log('[AI Engine] User skipped track quickly (Previous):', currentTrack.name);
      trackSkip(currentTrack);
    }

    if (currentTime > 3) {
      // If song played for more than 3 seconds, restart it
      seek(0);
      return;
    }

    if (isShuffle) {
      const randomIndex = Math.floor(Math.random() * queue.length);
      setQueueIndex(randomIndex);
      setCurrentTrack(queue[randomIndex]);
      return;
    }

    let prevIndex = queueIndex - 1;

    if (prevIndex < 0) {
      if (isRepeat === 'all') {
        prevIndex = queue.length - 1; // Wrap to last
      } else {
        prevIndex = 0; // Stick to first
      }
    }

    setQueueIndex(prevIndex);
    setCurrentTrack(queue[prevIndex]);
  };

  // --- Queue Alterations ---
  const addToQueue = (track) => {
    if (queue.some(t => t.id === track.id)) return; // Avoid duplicates
    setQueue([...queue, track]);
    if (queueIndex === -1) {
      setQueueIndex(0);
      setCurrentTrack(track);
    }
  };

  const addToQueueNext = (track) => {
    const filteredQueue = queue.filter(t => t.id !== track.id);
    const newQueue = [...filteredQueue];
    const insertPos = queueIndex + 1;
    newQueue.splice(insertPos, 0, track);
    setQueue(newQueue);
    if (queueIndex === -1) {
      setQueueIndex(0);
      setCurrentTrack(track);
    }
  };

  const removeFromQueue = (index) => {
    const newQueue = queue.filter((_, idx) => idx !== index);
    setQueue(newQueue);
    
    if (index === queueIndex) {
      // If we removed the playing track, play next
      if (newQueue.length === 0) {
        setCurrentTrack(null);
        setQueueIndex(-1);
        setIsPlaying(false);
        audioRef.current.pause();
        if (ytPlayerRef.current && typeof ytPlayerRef.current.stopVideo === 'function') {
          try {
            ytPlayerRef.current.stopVideo();
          } catch (e) {}
        }
      } else {
        const nextIdx = index >= newQueue.length ? 0 : index;
        setQueueIndex(nextIdx);
        setCurrentTrack(newQueue[nextIdx]);
      }
    } else if (index < queueIndex) {
      // Adjust index
      setQueueIndex(queueIndex - 1);
    }
  };

  const clearQueue = () => {
    audioRef.current.pause();
    audioRef.current.src = '';
    
    if (ytPlayerRef.current && typeof ytPlayerRef.current.stopVideo === 'function') {
      try {
        ytPlayerRef.current.stopVideo();
      } catch (e) {}
    }
    
    setCurrentTrack(null);
    setIsPlaying(false);
    setQueue([]);
    setQueueIndex(-1);
    setCurrentTime(0);
    setDuration(0);
  };

  const moveQueueItem = (fromIdx, toIdx) => {
    if (fromIdx < 0 || fromIdx >= queue.length || toIdx < 0 || toIdx >= queue.length) return;
    const newQueue = [...queue];
    const [movedItem] = newQueue.splice(fromIdx, 1);
    newQueue.splice(toIdx, 0, movedItem);
    
    // Adjust queueIndex
    let newIndex = queueIndex;
    if (queueIndex === fromIdx) {
      newIndex = toIdx;
    } else if (queueIndex > fromIdx && queueIndex <= toIdx) {
      newIndex -= 1;
    } else if (queueIndex < fromIdx && queueIndex >= toIdx) {
      newIndex += 1;
    }
    
    setQueue(newQueue);
    setQueueIndex(newIndex);
  };

  return (
    <AudioContext.Provider value={{
      currentTrack,
      isPlaying,
      duration,
      currentTime,
      volume,
      playbackSpeed,
      isShuffle,
      isRepeat,
      queue,
      queueIndex,
      isMuted,
      isBuffering,
      togglePlay,
      seek,
      changeVolume,
      toggleMute,
      changeSpeed,
      selectTrack,
      playNext,
      playPrevious,
      addToQueue,
      addToQueueNext,
      removeFromQueue,
      clearQueue,
      moveQueueItem,
      setIsShuffle,
      setIsRepeat
    }}>
      {children}
      <div 
        id="youtube-player" 
        style={{ 
          position: 'absolute', 
          width: '200px', 
          height: '200px', 
          top: '-9999px', 
          left: '-9999px', 
          opacity: 0, 
          pointerEvents: 'none',
          zIndex: -9999 
        }}
      ></div>
    </AudioContext.Provider>
  );
};

